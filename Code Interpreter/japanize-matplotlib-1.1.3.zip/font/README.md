japanize-matplotlib:

https://pypi.org/project/japanize-matplotlib/
