from src.utils.cleaning import normalize_plant_code, normalize_priority


def test_normalize_plant_code():
    assert normalize_plant_code("plt-02") == "PLT-002"


def test_normalize_priority():
    assert normalize_priority("高") == "High"