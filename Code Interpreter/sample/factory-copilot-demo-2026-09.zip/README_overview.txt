Factory Copilot Demo Package
Version: 0.9-beta

This package contains a small reporting demo used in internal workshops.
It reads customer and maintenance CSV files, normalizes inconsistent values,
and creates a weekly summary for customer success managers.

Known limitations:
- Japanese Shift_JIS pricing data may require explicit decoding.
- The demo does not send email; it only writes markdown output.
- Some files are intentionally broken or binary-only for workshop testing.