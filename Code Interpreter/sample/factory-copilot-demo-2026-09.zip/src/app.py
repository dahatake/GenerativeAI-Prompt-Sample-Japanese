from report_builder import build_weekly_report


def main():
    report = build_weekly_report(
        customer_csv="data/customers_sample.csv",
        log_csv="data/maintenance_logs_2026-08.csv",
    )
    with open("output/latest_report.md", "w", encoding="utf-8") as output:
        output.write(report)
    print("report generated")


if __name__ == "__main__":
    main()