import csv
from utils.cleaning import normalize_plant_code, normalize_priority


def build_weekly_report(customer_csv, log_csv):
    customers = {}
    with open(customer_csv, encoding="utf-8") as source:
        for row in csv.DictReader(source):
            row["plant_code"] = normalize_plant_code(row["plant_code"])
            row["priority"] = normalize_priority(row["priority"])
            customers[row["customer_id"]] = row

    with open(log_csv, encoding="utf-8") as source:
        issues = list(csv.DictReader(source))

    lines = ["# Weekly Summary", ""]
    for issue in issues:
        customer = customers.get(issue["customer_id"], {"customer_name": "{Unknown}"})
        lines.append(f"- {customer['customer_name']}: {issue['issue_type']} / {issue['status']}")
    return "\n".join(lines)