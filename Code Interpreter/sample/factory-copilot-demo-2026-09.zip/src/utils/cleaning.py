def normalize_plant_code(value: str) -> str:
    value = value.strip().upper().replace("_", "-")
    if value.startswith("PLT-") and len(value) == 6:
        return value[:4] + "0" + value[4:]
    return value


def normalize_priority(value: str) -> str:
    mapping = {"HIGH": "High", "高": "High", "MEDIUM": "Medium", "LOW": "Low"}
    key = value.strip().upper() if value else ""
    return mapping.get(key, value.title() if value else "Unknown")