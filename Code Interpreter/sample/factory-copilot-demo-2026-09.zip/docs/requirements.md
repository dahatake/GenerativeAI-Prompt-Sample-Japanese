# Requirements

## Goal
Generate a weekly customer-facing draft summary from workshop sample data.

## Functional requirements
1. Load customer master data.
2. Load maintenance logs.
3. Normalize plant codes and priority labels.
4. Aggregate open issues by customer and severity.
5. Output markdown summaries with "Facts / Risks / Next Actions".

## Non-functional requirements
- Run locally with Python 3.11
- Complete under 30 seconds for 5,000 rows
- Never expose real personal data

## Open questions
- Should pricing ranges be displayed to customers or internal users only?
- How should unreadable files be reported in the final summary?